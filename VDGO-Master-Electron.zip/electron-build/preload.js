// Preload for ВДГО Мастер
window.addEventListener('DOMContentLoaded', () => {
  document.body.classList.add('electron-app');
});
