@echo off
title VDGO Master - Build
cd /d "%~dp0"

echo ========================================
echo     VDGO MASTER - Build
echo ========================================
echo Current folder: %CD%
echo.

REM Check Node.js
node --version >nul 2>&1
if errorlevel 1 (
    echo [X] Node.js NOT found!
    echo.
    echo Install Node.js from:
    echo https://nodejs.org/dist/v22.14.0/node-v22.14.0-x64.msi
    echo.
    start https://nodejs.org/dist/v22.14.0/node-v22.14.0-x64.msi
    pause
    exit /b 1
)

echo [+] Node.js found
echo.

echo [1/4] Installing electron-builder...
call npm install
echo.

echo [2/4] Downloading Electron for Windows...
mkdir .cache 2>nul
powershell -Command "& {$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://github.com/electron/electron/releases/download/v42.2.0/electron-v42.2.0-win32-x64.zip' -OutFile '.cache\electron.zip' -TimeoutSec 300}"
if not exist ".cache\electron.zip" (
    echo [X] Download failed! Trying mirror...
    powershell -Command "& {$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://npmmirror.com/mirrors/electron/v42.2.0/electron-v42.2.0-win32-x64.zip' -OutFile '.cache\electron.zip' -TimeoutSec 300}"
)
if not exist ".cache\electron.zip" (
    echo [X] All mirrors failed!
    pause
    exit /b 1
)
echo [+] Downloaded OK
echo.

echo [3/4] Extracting Electron...
powershell -Command "& {Expand-Archive -Path '.cache\electron.zip' -DestinationPath '.cache\electron' -Force}"
echo [+] Extracted OK
echo.

echo [4/4] Copying app files...
mkdir ".cache\electron\resources\app" 2>nul
copy /Y main.js ".cache\electron\resources\app\" >nul
copy /Y preload.js ".cache\electron\resources\app\" >nul
copy /Y package.json ".cache\electron\resources\app\" >nul
echo [+] Files copied
echo.

echo ========================================
echo     DONE! Program ready!
echo ========================================
echo.
echo Folder with program:
echo     %CD%\.cache\electron\
echo.
echo To run: double-click electron.exe in that folder
echo.
echo Creating shortcut on desktop...
set SHORTCUT="%USERPROFILE%\Desktop\VDGO Master.lnk"
powershell -Command "$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%SHORTCUT%'); $Shortcut.TargetPath = '%CD%\.cache\electron\electron.exe'; $Shortcut.WorkingDirectory = '%CD%\.cache\electron'; $Shortcut.IconLocation = '%CD%\.cache\electron\electron.exe,0'; $Shortcut.Save()"
echo [+] Shortcut created on desktop!
echo.
explorer.exe "%CD%\.cache\electron"
pause
